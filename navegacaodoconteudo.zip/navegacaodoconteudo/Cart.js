import React, { useState, useMemo } from 'react';
import { StyleSheet, View, Text, TextInput, ScrollView, TouchableOpacity, Image, Alert } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import logo from './assets/logo.png';

const initialProducts = [
  { id: 1, name: 'FEIJÃO', price: 10.99, image: logo },
  { id: 2, name: 'ÁÇUCAR', price: 5.00, image: logo },
  { id: 3, name: 'ARROZ', price: 20.00, image: logo },
  { id: 4, name: 'COCA COLA 2L', price: 25.00, image: logo },
  { id: 5, name: 'ITAIPAVA LATA', price: 24.90, image: logo },
  { id: 6, name: 'Produto F', price: 12.80, image: logo },
  { id: 7, name: 'Produto G', price: 22.20, image: logo },
  { id: 8, name: 'Produto H', price: 15.00, image: logo },
  { id: 9, name: 'Produto I', price: 9.00, image: logo },
  { id: 10, name: 'Produto J', price: 5.99, image: logo },
];

const ProductItem = ({ product, index, quantity, onUpdate }) => (
  <View style={styles.productItem}>
    <Image source={product.image} style={styles.productImage} />
    <Text style={styles.productName}>{product.name}</Text>
    <Text style={styles.productPrice}>R$ {product.price.toFixed(2)}</Text>
    <View style={styles.quantityContainer}>
      <TouchableOpacity onPress={() => onUpdate(index, -1)}>
        <Text style={styles.quantityButton}>-</Text>
      </TouchableOpacity>
      <Text style={styles.quantityText}>{quantity}</Text>
      <TouchableOpacity onPress={() => onUpdate(index, 1)}>
        <Text style={styles.quantityButton}>+</Text>
      </TouchableOpacity>
    </View>
  </View>
);

export default function Cart({ navigation, route }) {
  const { supermarketName } = route.params || { supermarketName: '' };
  const [quantities, setQuantities] = useState(initialProducts.map(() => 0));
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('carrinho');
  const [totalBalance, setTotalBalance] = useState(200.00);

  const filteredProducts = initialProducts.filter(product =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const updateQuantity = (index, delta) => {
    const newQuantities = [...quantities];
    const newQuantity = newQuantities[index] + delta;

    if (newQuantity < 0) return; // Impede quantidade negativa

    const cost = initialProducts[index].price;
    
    if (delta > 0 && totalBalance < cost) return; // Verifica saldo

    newQuantities[index] = newQuantity;
    setQuantities(newQuantities);
    setTotalBalance(prevBalance => prevBalance - cost * delta); // Atualiza saldo
  };

  const calculateTotalConsumption = () => {
    return quantities.reduce((total, quantity, index) => total + (quantity * initialProducts[index].price), 0);
  };

  const totalConsumption = useMemo(calculateTotalConsumption, [quantities]);

  const handleTabChange = (tab) => {
    setActiveTab(tab.name);
    navigation.navigate(tab.name === 'carrinho' ? 'Cart' : tab.name === 'perfil' ? 'Profile' : 'ChooseSupermarket');
  };

  const handleFinalizePurchase = () => {
    if (totalConsumption > 0) {
      const orders = initialProducts.map((product, index) => ({
        name: product.name,
        quantity: quantities[index],
        price: product.price,
      })).filter(order => order.quantity > 0);

      if (orders.length > 0) {
        navigation.navigate('Orders', { orders, totalBalance, totalConsumption });
      }
    } else {
      Alert.alert("Nenhum produto selecionado", "Adicione produtos ao carrinho antes de finalizar a compra.");
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.logoContainer}>
        <Image source={logo} style={styles.logo} />
      </View>

      <Text style={styles.title}>
        Produtos em Estoque {supermarketName && `- ${supermarketName}`}
      </Text>

      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Pesquise seu produto..."
          placeholderTextColor="#aaaaaa"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        <Icon name="search" size={24} color="white" style={styles.searchIcon} />
      </View>

      <ScrollView style={styles.productScroll}>
        <View style={styles.productGrid}>
          {filteredProducts.map((product, index) => (
            <ProductItem 
              key={product.id} 
              product={product} 
              index={index} 
              quantity={quantities[index]} 
              onUpdate={updateQuantity} 
            />
          ))}
        </View>
      </ScrollView>

      <View style={styles.balanceContainer}>
        <View style={styles.balanceItem}>
          <Text style={styles.balanceText}>Saldo:</Text>
          <Text style={styles.balanceValue}>R$ {totalBalance.toFixed(2)}</Text>
        </View>
        <View style={styles.consumptionItem}>
          <Text style={styles.consumptionText}>Consumo Total:</Text>
          <Text style={styles.consumptionValue}>R$ {totalConsumption.toFixed(2)}</Text>
        </View>
      </View>

      <TouchableOpacity style={styles.finalizeButton} onPress={handleFinalizePurchase}>
        <Text style={styles.finalizeButtonText}>Finalizar Compra</Text>
      </TouchableOpacity>

      <View style={styles.navBar}>
        {[
          { name: 'casa', icon: 'home', label: 'Início' },
          { name: 'carrinho', icon: 'cart', label: 'Carrinho' },
          { name: 'prancheta', icon: 'clipboard', label: 'Pedidos' },
          { name: 'perfil', icon: 'person', label: 'Perfil' },
        ].map((tab) => (
          <TouchableOpacity 
            key={tab.name} 
            style={styles.navItem} 
            onPress={() => handleTabChange(tab)}
          >
            {activeTab === tab.name && <View style={styles.activeCircle} />}
            <View style={styles.iconContainer}>
              <Icon name={tab.icon} size={24} color={activeTab === tab.name ? 'white' : 'rgb(2, 92, 70)'} />
              <Text style={[styles.navLabel, { color: activeTab === tab.name ? 'white' : 'rgb(2, 92, 70)' }]}>
                {tab.label}
              </Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgb(2, 92, 70)',
    padding: 20,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 5,
  },
  logo: {
    width: 150,
    height: 150,
  },
  title: {
    fontSize: 24,
    color: 'white',
    textAlign: 'center',
    marginBottom: 20,
  },
  searchContainer: {
    position: 'relative',
    marginBottom: 20,
  },
  searchInput: {
    height: 40,
    borderColor: '#056656',
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 40,
    color: 'white',
  },
  searchIcon: {
    position: 'absolute',
    right: 10,
    top: 10,
  },
  productScroll: {
    marginBottom: 20,
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 10,
  },
  productGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  productItem: {
    alignItems: 'center',
    width: '48%',
    marginBottom: 15,
  },
  productImage: {
    width: 100,
    height: 100,
    borderRadius: 10,
  },
  productName: {
    marginTop: 5,
    color: '#056656',
    textAlign: 'center',
  },
  productPrice: {
    color: '#056656',
    fontSize: 16,
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
  },
  quantityButton: {
    backgroundColor: 'rgb(2, 92, 70)',
    color: 'white',
    padding: 10,
    borderRadius: 5,
    width: 30,
    textAlign: 'center',
  },
  quantityText: {
    marginHorizontal: 10,
    fontSize: 16,
  },
  balanceContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    marginBottom: 5,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderRadius: 5,
  },
  balanceItem: {
    alignItems: 'flex-start',
  },
  consumptionItem: {
    alignItems: 'flex-start',
  },
  balanceText: {
    color: 'white',
    fontSize: 16,
  },
  balanceValue: {
    color: 'white',
    fontSize: 24,
  },
  consumptionText: {
    color: 'white',
    fontSize: 16,
  },
  consumptionValue: {
    color: 'white',
    fontSize: 24,
  },
  finalizeButton: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 50,
  },
  finalizeButtonText: {
    color: 'rgb(2, 92, 70)',
    fontSize: 18,
  },
  navBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 10,
    backgroundColor: 'white',
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    elevation: 5,
  },
  navItem: {
    alignItems: 'center',
    position: 'relative',
  },
  iconContainer: {
    alignItems: 'center',
  },
  navLabel: {
    fontSize: 12,
    marginTop: 4,
  },
  activeCircle: {
    position: 'absolute',
    bottom: -5,
    width: 55,
    height: 55,
    borderRadius: 30,
    backgroundColor: 'rgb(2, 92, 70)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: -1,
  },
});
