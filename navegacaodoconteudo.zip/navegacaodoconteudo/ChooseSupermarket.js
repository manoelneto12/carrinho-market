import React, { useState } from 'react';
import { StyleSheet, View, Text, TextInput, ScrollView, TouchableOpacity, Image } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import logo from './assets/logo.png';
import carrefourLogo from './assets/carrefour.png';

export default function ChooseSupermarket({ navigation }) {
  const [activeTab, setActiveTab] = useState('casa');
  const [searchText, setSearchText] = useState('');
  
  const supermarkets = [
    { id: 1, name: 'Carrefour', logo: carrefourLogo },
    { id: 2, name: 'Supermercado B', logo: logo },
    { id: 3, name: 'Supermercado C', logo: logo },
    { id: 4, name: 'Supermercado D', logo: logo },
    { id: 5, name: 'Supermercado E', logo: logo },
    { id: 6, name: 'Supermercado F', logo: logo },
    { id: 7, name: 'Supermercado G', logo: logo },
    { id: 8, name: 'Supermercado H', logo: logo },
  ];

  const handleTabChange = (tab) => {
    setActiveTab(tab.name);
    navigation.navigate(tab.name === 'carrinho' ? 'Cart' : tab.name === 'perfil' ? 'Profile' : 'ChooseSupermarket');
  };

  const handleSupermarketSelect = (supermarketName) => {
    navigation.navigate('Cart', { supermarketName });
  };

  const filteredSupermarkets = supermarkets.filter((supermarket) =>
    supermarket.name.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <View style={styles.logoContainer}>
        <Image source={logo} style={styles.logo} />
      </View>

      <Text style={styles.title}>Escolha Seu Supermercado</Text>

      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Pesquise seu supermercado..."
          placeholderTextColor="#aaaaaa"
          value={searchText}
          onChangeText={setSearchText}
        />
        <Icon name="search" size={24} color="white" style={styles.searchIcon} />
      </View>

      <ScrollView style={styles.supermarketScroll}>
        <View style={styles.supermarketGrid}>
          {filteredSupermarkets.map((supermarket) => (
            <TouchableOpacity 
              key={supermarket.id} 
              style={styles.supermarketItem} 
              onPress={() => handleSupermarketSelect(supermarket.name)}
              accessibilityLabel={`Selecionar ${supermarket.name}`}
              accessibilityHint={`Navega para o carrinho com o supermercado ${supermarket.name}`}
            >
              <Image source={supermarket.logo} style={styles.supermarketLogo} />
              <Text style={styles.supermarketName}>{supermarket.name}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      <View style={styles.balanceContainer}>
        <Text style={styles.balanceText}>Saldo:</Text>
        <Text style={styles.balanceValue}>R$ 200,00</Text>
      </View>

      <View style={styles.navBar}>
        {[ 
          { name: 'casa', icon: 'home', label: 'Início' }, 
          { name: 'carrinho', icon: 'cart', label: 'Carrinho' },
          { name: 'prancheta', icon: 'clipboard', label: 'Pedidos' },
          { name: 'perfil', icon: 'person', label: 'Perfil' },
        ].map((tab) => (
          <TouchableOpacity
            key={tab.name}
            style={styles.navItem}
            onPress={() => handleTabChange(tab)}
            accessibilityLabel={tab.label}
            accessibilityHint={`Navega para ${tab.label}`}
          >
            {activeTab === tab.name && <View style={styles.activeCircle} />}
            <View style={styles.iconContainer}>
              <Icon
                name={tab.icon}
                size={24}
                color={activeTab === tab.name ? 'white' : 'rgb(2, 92, 70)'}
              />
              <Text style={[styles.navLabel, { color: activeTab === tab.name ? 'white' : 'rgb(2, 92, 70)' }]}>
                {tab.label}
              </Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgb(2, 92, 70)',
    padding: 20,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 5,
  },
  logo: {
    width: 150,
    height: 150,
  },
  title: {
    fontSize: 24,
    color: 'white',
    textAlign: 'center',
    marginBottom: 20,
  },
  searchContainer: {
    position: 'relative',
    marginBottom: 20,
  },
  searchInput: {
    height: 40,
    borderColor: '#056656',
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 40,
    color: 'white',
  },
  searchIcon: {
    position: 'absolute',
    right: 10,
    top: 10,
  },
  supermarketScroll: {
    marginBottom: 20,
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 10,
  },
  supermarketGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  supermarketItem: {
    alignItems: 'center',
    width: '48%',
    marginBottom: 20,
  },
  supermarketLogo: {
    width: 100,
    height: 100,
    borderRadius: 10,
  },
  supermarketName: {
    marginTop: 5,
    color: '#056656',
    textAlign: 'center',
  },
  balanceContainer: {
    flexDirection: 'column',
    alignItems: 'flex-start',
    padding: 10,
    marginBottom: 55,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderRadius: 5,
  },
  balanceText: {
    color: 'white',
    fontSize: 16,
  },
  balanceValue: {
    color: 'white',
    fontSize: 24,
  },
  navBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 10,
    backgroundColor: 'white',
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    elevation: 5,
  },
  navItem: {
    alignItems: 'center',
    position: 'relative',
  },
  iconContainer: {
    alignItems: 'center',
  },
  navLabel: {
    fontSize: 12,
    marginTop: 4,
  },
  activeCircle: {
    position: 'absolute',
    bottom: -5,
    width: 55,
    height: 55,
    borderRadius: 30,
    backgroundColor: 'rgb(2, 92, 70)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: -1,
  },
});
