import React, { useState } from 'react';
import {
  StyleSheet, View, Text, TextInput, Alert, TouchableOpacity,
  KeyboardAvoidingView, Platform, ScrollView, TouchableWithoutFeedback,
  Keyboard, Image
} from 'react-native';

const isValidEmail = (email) => {
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailPattern.test(email);
};

export default function ForgotPasswordScreen({ navigation }) {
  const [email, setEmail] = useState('');

  const handleForgotPassword = () => {
    if (isValidEmail(email)) {
      Alert.alert('Recuperar Senha', 'Instruções foram enviadas para o seu email.');
    } else {
      Alert.alert('Erro', 'Por favor, insira um email válido.');
    }
  };

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'android' ? 'height' : 'padding'}
      >
        <View style={styles.mainContainer}>
          <ScrollView contentContainerStyle={styles.scrollContainer}>
            <View style={styles.logoContainer}>
              <Image source={require('./assets/logo.png')} style={styles.logo} />
            </View>
            <View style={styles.inputContainer}>
              <Text style={styles.title}>Recuperar Senha</Text>
              <TextInput style={styles.input} placeholder="Email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" placeholderTextColor="white" />
            </View>
          </ScrollView>

          <View style={styles.whiteBackground}>
            <TouchableOpacity onPress={() => navigation.navigate('Login')}>
              <Text style={styles.switchToLogin}>Voltar ao login</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.loginButton} onPress={handleForgotPassword}>
              <Text style={styles.loginButtonText}>RECUPERAR SENHA</Text>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgb(2, 92, 70)', // Cor do fundo principal
  },
  mainContainer: {
    flex: 1,
    justifyContent: 'flex-start',
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'flex-start',
    padding: 20,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 30,
  },
  logo: {
    width: 200,
    height: 200,
    resizeMode: 'contain',
  },
  inputContainer: {
    width: '100%',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginBottom: 30,
  },
  input: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)', // Cor da caixa de texto
    color: 'white',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
    width: '100%',
  },
 // fundo branco dos boteos 
  whiteBackground: {
    width: '100%',
    padding: 15,
    backgroundColor: 'white',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    alignItems: 'center',
  },
  
  loginButton: {
    backgroundColor: '#056656', // Cor do botão
    paddingVertical: 12,
    width: '100%',
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 10,
  },
   switchToLogin: {
    color: '#056656', // Cor do texto "já tem uma conta"
    textAlign: 'center',
    marginBottom: 20,
  },
  loginButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});


