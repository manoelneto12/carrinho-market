import React, { useState } from 'react';
import {
  StyleSheet, View, Text, TextInput, Alert, TouchableOpacity, 
  KeyboardAvoidingView, Platform, ScrollView, TouchableWithoutFeedback, 
  Keyboard, Image
} from 'react-native';

const isValidEmail = (email) => {
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailPattern.test(email);
};

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(false);

  const handleLogin = () => {
    if (email && password) {
      if (isValidEmail(email)) {
        Alert.alert('Login bem-sucedido!', `Email: ${email}`);
         navigation.navigate('ChooseSupermarket');
      } else {
        Alert.alert('Erro', 'Por favor, insira um email válido.');
      }
    } else {
      Alert.alert('Erro', 'Por favor, preencha todos os campos.');
    }
  };

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'android' ? 'height' : 'padding'}
      >
        <View style={styles.mainContainer}>
          <ScrollView contentContainerStyle={styles.scrollContainer}>
            <View style={styles.logoContainer}>
              <Image source={require('./assets/logo.png')} style={styles.logo} />
            </View>
            <View style={styles.inputContainer}>
              <Text style={styles.title}>LOGIN</Text>
              <TextInput
                style={styles.input}
                placeholder="Email"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                placeholderTextColor="white"
              />
              <TextInput
                style={styles.input}
                placeholder="Senha"
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!passwordVisible}
                placeholderTextColor="white"
              />
              <TouchableOpacity onPress={() => setPasswordVisible(!passwordVisible)} style={styles.showPassword}>
                <Text style={styles.showPasswordText}>
                  {passwordVisible ? 'Ocultar Senha' : 'Mostrar Senha'}
                </Text>
              </TouchableOpacity>
            </View>
          </ScrollView>

          <View style={styles.whiteBackground}>
            <TouchableOpacity onPress={() => navigation.navigate('ForgotPassword')}>
              <Text style={styles.forgotPassword}>Esqueci minha senha</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
              <Text style={styles.loginButtonText}>ENTRAR</Text>
            </TouchableOpacity>
            <Text style={styles.orText}>OU</Text>
            <TouchableOpacity style={styles.loginButton} onPress={() => navigation.navigate('Register')}>
              <Text style={styles.loginButtonText}>CADASTRAR</Text>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgb(2, 92, 70)', // Cor do fundo principal
  },
  mainContainer: {
    flex: 1,
    justifyContent: 'flex-start',
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'flex-start',
    padding: 20,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 30,
  },
  logo: {
    width: 200,
    height: 200,
    resizeMode: 'contain',
  },
  inputContainer: {
    width: '100%',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginBottom: 30,
  },
  input: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)', // Cor da caixa de texto
    color: 'white',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
    width: '100%',
  },
  showPassword: {
    alignSelf: 'flex-start',
    marginBottom: 100,
    marginLeft: '1%',
  },
  showPasswordText: {
    color: 'white',
    fontSize: 14,
  },
  whiteBackground: {
    width: '100%',
    padding: 20,
    backgroundColor: 'white',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    alignItems: 'center',
  },
  forgotPassword: {
    color: '#056656', // Cor do texto "esqueci minha senha"
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
  },
  loginButton: {
     backgroundColor: '#056656', // Cor do botão
    paddingVertical: 12,
    width: '100%',
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 1,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 5,
  },
  loginButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  orText: {
     color: '#056656', // Cor do texto "OU"
    fontSize: 14,
    marginVertical: 10,
  },
 });

