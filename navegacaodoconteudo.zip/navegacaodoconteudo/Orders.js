import React, { useState, useCallback, useMemo } from 'react';
import { StyleSheet, View, Text, ScrollView, TouchableOpacity, Image } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import logo from './assets/logo.png';

const Orders = ({ route, navigation }) => {
  const { orders = [], totalBalance = 0, totalConsumption = 0 } = route.params || {};
  const [activeTab, setActiveTab] = useState('prancheta');

  const handleTabChange = useCallback((tab) => {
    setActiveTab(tab.name);
    navigation.navigate(tab.name === 'carrinho' ? 'Cart' : tab.name === 'perfil' ? 'Profile' : 'Orders');
  }, [navigation]);

  const renderOrderItem = (order) => (
    <View key={order.id} style={styles.orderItem}>
      <Text style={styles.productName}>{order.name}</Text>
      <Text style={styles.productQuantity}>Quantidade: {order.quantity}</Text>
      <Text style={styles.productPrice}>Preço: R$ {(order.price * order.quantity).toFixed(2)}</Text>
    </View>
  );

  const orderItems = useMemo(() => {
    return orders.length > 0 ? orders.map(renderOrderItem) : (
      <Text style={styles.noOrdersText}>Nenhum pedido feito ainda.</Text>
    );
  }, [orders]);

  return (
    <View style={styles.container}>
      <View style={styles.logoContainer}>
        <Image source={logo} style={styles.logo} />
      </View>

      <Text style={styles.title}>Meus Pedidos</Text>

      <ScrollView style={styles.ordersScroll}>
        {orderItems}
      </ScrollView>

      <View style={styles.balanceContainer}>
        <View style={styles.balanceItem}>
          <Text style={styles.balanceText}>Saldo:</Text>
          <Text style={styles.balanceValue}>R$ {totalBalance.toFixed(2)}</Text>
        </View>
        <View style={styles.consumptionItem}>
          <Text style={styles.consumptionText}>Consumo Total:</Text>
          <Text style={styles.consumptionValue}>R$ {totalConsumption.toFixed(2)}</Text>
        </View>
      </View>

      <View style={styles.navBar}>
        {[
          { name: 'casa', icon: 'home', label: 'Início' },
          { name: 'carrinho', icon: 'cart', label: 'Carrinho' },
          { name: 'prancheta', icon: 'clipboard', label: 'Pedidos' },
          { name: 'perfil', icon: 'person', label: 'Perfil' },
        ].map((tab) => (
          <TouchableOpacity
            key={tab.name}
            style={styles.navItem}
            onPress={() => handleTabChange(tab)}
            accessibilityLabel={tab.label}
            accessibilityHint={`Navega para ${tab.label}`}
          >
            {activeTab === tab.name && <View style={styles.activeCircle} />}
            <View style={styles.iconContainer}>
              <Icon name={tab.icon} size={24} color={activeTab === tab.name ? 'white' : 'rgb(2, 92, 70)'} />
              <Text style={[styles.navLabel, { color: activeTab === tab.name ? 'white' : 'rgb(2, 92, 70)' }]}>
                {tab.label}
              </Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgb(2, 92, 70)',
    padding: 20,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 5,
  },
  logo: {
    width: 150,
    height: 150,
  },
  title: {
    fontSize: 24,
    color: 'white',
    textAlign: 'center',
    marginBottom: 20,
  },
  balanceContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    marginBottom: 50,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderRadius: 5,
  },
  balanceItem: {
    alignItems: 'flex-start',
  },
  consumptionItem: {
    alignItems: 'flex-start',
  },
  balanceText: {
    color: 'white',
    fontSize: 16,
  },
  balanceValue: {
    color: 'white',
    fontSize: 24,
  },
  consumptionText: {
    color: 'white',
    fontSize: 16,
  },
  consumptionValue: {
    color: 'white',
    fontSize: 24,
  },
  ordersScroll: {
    marginBottom: 50,
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 10,
  },
  orderItem: {
    marginBottom: 15,
  },
  productName: {
    fontSize: 18,
    color: '#056656',
  },
  productQuantity: {
    fontSize: 16,
    color: '#056656',
  },
  productPrice: {
    fontSize: 16,
    color: '#056656',
  },
  noOrdersText: {
    textAlign: 'center',
    color: '#056656',
  },
  navBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 10,
    backgroundColor: 'white',
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    elevation: 5,
  },
  navItem: {
    alignItems: 'center',
    position: 'relative',
  },
  iconContainer: {
    alignItems: 'center',
  },
  navLabel: {
    fontSize: 12,
    marginTop: 4,
  },
  activeCircle: {
    position: 'absolute',
    bottom: -5,
    width: 55,
    height: 55,
    borderRadius: 30,
    backgroundColor: 'rgb(2, 92, 70)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: -1,
  },
});

export default Orders;
