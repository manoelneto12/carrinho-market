import React, { useState } from 'react';
import { StyleSheet, View, Text, TextInput, TouchableOpacity, Image, Alert } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import logo from './assets/logo.png';

export default function ProfileScreen({ navigation }) {
  const [username] = useState('Nome do Usuário');
  const [email] = useState('usuario@exemplo.com');
  const [password] = useState('senha123');
  const [showPassword, setShowPassword] = useState(false);
  const [balance, setBalance] = useState('');
  const [activeTab, setActiveTab] = useState('perfil');

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab.name);
    navigation.navigate(tab.name === 'carrinho' ? 'Cart' : tab.name === 'perfil' ? 'Profile' : 'ChooseSupermarket');
  };

  const handleAddBalance = () => {
    const balanceValue = parseFloat(balance);
    if (isNaN(balanceValue) || balanceValue <= 0) {
      Alert.alert('Erro', 'Por favor, insira um valor válido para o saldo.');
      return;
    }
    Alert.alert('Sucesso', `Saldo de R$ ${balanceValue.toFixed(2)} adicionado com sucesso!`);
    setBalance(''); // Limpa o campo após a adição
  };

  return (
    <View style={styles.container}>
      <View style={styles.logoContainer}>
        <Image source={logo} style={styles.logo} />
      </View>

      <Text style={styles.title}>Perfil do Usuário</Text>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Nome:</Text>
        <Text style={styles.displayText}>{username}</Text>
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Email:</Text>
        <Text style={styles.displayText}>{email}</Text>
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Senha:</Text>
        <View style={styles.passwordContainer}>
          <TextInput
            style={styles.passwordInput}
            value={showPassword ? password : '********'}
            secureTextEntry={!showPassword}
          />
          <TouchableOpacity onPress={togglePasswordVisibility} style={styles.iconButton}>
            <Icon name={showPassword ? 'eye-off' : 'eye'} size={24} color="black" />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Adicionar Saldo:</Text>
        <TextInput
          style={styles.input}
          value={balance}
          onChangeText={setBalance}
          placeholder="Digite o saldo"
          keyboardType="numeric"
        />
      </View>

      <TouchableOpacity style={styles.addButton} onPress={handleAddBalance} accessibilityLabel="Adicionar saldo" accessibilityHint="Confirma a adição do saldo inserido">
        <Text style={styles.addButtonText}>Confirmar Adição de Saldo</Text>
      </TouchableOpacity>

      <View style={styles.navBar}>
        {[
          { name: 'casa', icon: 'home', label: 'Início' },
          { name: 'carrinho', icon: 'cart', label: 'Carrinho' },
          { name: 'prancheta', icon: 'clipboard', label: 'Pedidos' },
          { name: 'perfil', icon: 'person', label: 'Perfil' },
        ].map((tab) => (
          <TouchableOpacity
            key={tab.name}
            style={styles.navItem}
            onPress={() => handleTabChange(tab)}
            accessibilityLabel={tab.label}
            accessibilityHint={`Navega para ${tab.label}`}
          >
            {activeTab === tab.name && <View style={styles.activeCircle} />}
            <View style={styles.iconContainer}>
              <Icon
                name={tab.icon}
                size={24}
                color={activeTab === tab.name ? 'white' : 'rgb(2, 92, 70)'}
              />
              <Text style={[styles.navLabel, { color: activeTab === tab.name ? 'white' : 'rgb(2, 92, 70)' }]}>
                {tab.label}
              </Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgb(2, 92, 70)',
    padding: 20,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 5,
  },
  logo: {
    width: 150,
    height: 150,
  },
  title: {
    fontSize: 24,
    color: 'white',
    textAlign: 'center',
    marginBottom: 20,
  },
  inputContainer: {
    marginBottom: 15,
  },
  label: {
    color: 'white',
    marginBottom: 5,
  },
  displayText: {
    height: 40,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderRadius: 5,
    paddingHorizontal: 10,
    paddingVertical: 10,
    color: 'black',
  },
  passwordContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#056656',
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderRadius: 5,
    height: 40,
  },
  passwordInput: {
    flex: 1,
    paddingHorizontal: 10,
    paddingVertical: 5,
    color: 'black',
  },
  iconButton: {
    justifyContent: 'center',
    paddingHorizontal: 10,
  },
  input: {
    height: 40,
    borderColor: '#056656',
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
    color: 'black',
    textAlign: 'center',
  },
  addButton: {
    backgroundColor: 'white',
    padding: 10,
    borderRadius: 5,
    marginTop: 20,
  },
  addButtonText: {
    color: 'rgb(2, 92, 70)',
    textAlign: 'center',
  },
  navBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 10,
    backgroundColor: 'white',
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    elevation: 5,
  },
  navItem: {
    alignItems: 'center',
    position: 'relative',
  },
  iconContainer: {
    alignItems: 'center',
  },
  navLabel: {
    fontSize: 12,
    marginTop: 4,
  },
  activeCircle: {
    position: 'absolute',
    bottom: -5,
    width: 55,
    height: 55,
    borderRadius: 30,
    backgroundColor: 'rgb(2, 92, 70)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: -1,
  },
});
